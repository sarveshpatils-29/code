
const express = require("express");
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.static(__dirname));

// MySQL connection
const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "sarvesh",
    database: "student_registration"
});

// Register student
app.post("/register", async function(req, res) {
    try {
        const { name, email, phone, course, password } = req.body;

        if (!name || !email || !phone || !course || !password) {
            return res.status(400).json({
                message: "All fields are required."
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        await db.execute(
            "INSERT INTO students (name, email, phone, course, password) VALUES (?, ?, ?, ?, ?)",
            [
                name.trim(),
                email.trim().toLowerCase(),
                phone,
                course,
                hashedPassword
            ]
        );

        res.status(201).json({
            message: "Registration successful! Data saved in MySQL."
        });

    } catch (error) {
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This email is already registered."
            });
        }

        console.log(error);

        res.status(500).json({
            message: "Registration failed. Please try again."
        });
    }
});

// View registered students
app.get("/users", async function(req, res) {
    try {
        const [users] = await db.execute(
            "SELECT id, name, email, phone, course FROM students ORDER BY id DESC"
        );

        res.json(users);

    } catch (error) {
        res.status(500).json({
            message: "Unable to fetch students."
        });
    }
});

// Start server
async function startServer() {
    try {
        await db.query("SELECT 1");
        console.log("MySQL connected successfully!");

        app.listen(PORT, function() {
            console.log("Server running at http://localhost:" + PORT);
        });

    } catch (error) {
        console.log("MySQL connection failed:", error.message);
    }
}

startServer();