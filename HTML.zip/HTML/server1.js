const express = require("express");
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = 3001;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: "my_event_management_secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        secure: false, // false for localhost
        maxAge: 60 * 60 * 1000
    }
}));

// MySQL Connection
const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "sarvesh",
    database: "event_management",
    waitForConnections: true,
    connectionLimit: 10
});

// Serve HTML
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "login.html"));
});

// Check Admin Session
function checkAdmin(req, res, next) {
    if (!req.session.adminId) {
        return res.status(401).json({
            message: "Please login first"
        });
    }
    next();
}

// 1. ADMIN LOGIN
app.post("/login", async (req, res) => {
    try {
        const { username, password } = req.body;

        const [rows] = await db.execute(
            "SELECT * FROM admins WHERE username = ?",
            [username]
        );

        if (rows.length === 0) {
            return res.status(401).json({
                message: "Invalid username or password"
            });
        }

        const admin = rows[0];

        const validPassword = await bcrypt.compare(
            password,
            admin.password
        );

        if (!validPassword) {
            return res.status(401).json({
                message: "Invalid username or password"
            });
        }

        req.session.adminId = admin.id;

        res.json({
            message: "Login successful"
        });

    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({
            message: "Login failed"
        });
    }
});

// 2. CHECK SESSION
app.get("/me", checkAdmin, (req, res) => {
    res.json({ loggedIn: true });
});

// 3. LOGOUT
app.post("/logout", (req, res) => {
    req.session.destroy((error) => {
        if (error) {
            return res.status(500).json({
                message: "Logout failed"
            });
        }

        res.clearCookie("connect.sid");

        res.json({
            message: "Logout successful"
        });
    });
});

// 4. ADD EVENT
app.post("/events", checkAdmin, async (req, res) => {
    try {
        const {
            title,
            category,
            event_date,
            location,
            description
        } = req.body;

        if (!title || !event_date || !category || !location) {
            return res.status(400).json({
                message: "Please fill all required fields"
            });
        }

        await db.execute(
            `INSERT INTO events
            (event_name, category, event_date, location, description)
            VALUES (?, ?, ?, ?, ?)`,
            [
                title,
                category,
                event_date,
                location,
                description || ""
            ]
        );

        res.json({
            message: "Event added successfully"
        });

    } catch (error) {
        console.error("Add event error:", error);
        res.status(500).json({
            message: "Error adding event"
        });
    }
});

// 5. VIEW ALL EVENTS
app.get("/events", checkAdmin, async (req, res) => {
    try {
        const [events] = await db.execute(
            `SELECT
                id,
                event_name AS title,
                category,
                DATE_FORMAT(event_date, '%Y-%m-%d') AS event_date,
                location,
                description
             FROM events
             ORDER BY id DESC`
        );

        res.json(events);

    } catch (error) {
        console.error("Fetch events error:", error);
        res.status(500).json({
            message: "Error fetching events"
        });
    }
});

// 6. UPDATE EVENT
app.put("/events/:id", checkAdmin, async (req, res) => {
    try {
        const {
            title,
            category,
            event_date,
            location,
            description
        } = req.body;

        if (!title || !event_date || !category || !location) {
            return res.status(400).json({
                message: "Please fill all required fields"
            });
        }

        const [result] = await db.execute(
            `UPDATE events
             SET event_name = ?,
                 category = ?,
                 event_date = ?,
                 location = ?,
                 description = ?
             WHERE id = ?`,
            [
                title,
                category,
                event_date,
                location,
                description || "",
                req.params.id
            ]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Event not found"
            });
        }

        res.json({
            message: "Event updated successfully"
        });

    } catch (error) {
        console.error("Update event error:", error);
        res.status(500).json({
            message: "Error updating event"
        });
    }
});

// 7. DELETE EVENT
app.delete("/events/:id", checkAdmin, async (req, res) => {
    try {
        const [result] = await db.execute(
            "DELETE FROM events WHERE id = ?",
            [req.params.id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Event not found"
            });
        }

        res.json({
            message: "Event deleted successfully"
        });

    } catch (error) {
        console.error("Delete event error:", error);
        res.status(500).json({
            message: "Error deleting event"
        });
    }
});

// START SERVER
async function startServer() {
    try {
        await db.execute("SELECT 1");

        console.log("MySQL connected successfully!");

        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
        });

    } catch (error) {
        console.error("Database connection failed:", error.message);
    }
}

startServer();



