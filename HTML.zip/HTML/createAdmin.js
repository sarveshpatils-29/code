const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");

async function createAdmin() {
    let db;

    try {
        db = await mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "sarvesh",
            database: "event_management"
        });

        const username = "admin";
        const password = "Admin123";

        const hashedPassword = await bcrypt.hash(password, 10);

        await db.execute(
            `INSERT INTO admins (username, password)
             VALUES (?, ?)
             ON DUPLICATE KEY UPDATE password = ?`,
            [username, hashedPassword, hashedPassword]
        );

        console.log("Admin account created successfully!");

    } catch (error) {
        console.error("Error creating admin:", error.message);

    } finally {
        if (db) await db.end();
    }
}

createAdmin();
