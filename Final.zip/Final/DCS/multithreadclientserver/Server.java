import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;

interface Hello extends Remote {
    String sayHello(String name) throws RemoteException;
}

public class Server extends UnicastRemoteObject implements Hello {

    Server() throws RemoteException {}

    public String sayHello(String name) {
        return "Hello " + name;
    }

    public static void main(String[] args) throws Exception {
        LocateRegistry.createRegistry(1099);
        Naming.rebind("Hello", new Server());
        System.out.println("Server Started");
    }
}