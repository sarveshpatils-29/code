import java.rmi.*;

public class Client {
    public static void main(String[] args) throws Exception {

        Hello obj = (Hello) Naming.lookup("rmi://localhost/Hello");

        for (int i = 1; i <= 3; i++) {
            final int n = i;

            new Thread(() -> {
                try {
                    System.out.println(obj.sayHello("Client " + n));
                } catch (Exception e) {
                    System.out.println(e);
                }
            }).start();
        }
    }
}