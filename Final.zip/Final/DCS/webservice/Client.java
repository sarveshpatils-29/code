import java.net.*;
import java.io.*;

public class Client {
    public static void main(String[] args) throws Exception {

        URL url = new URL("http://localhost:8080/add?a=10&b=20");

        HttpURLConnection con =
            (HttpURLConnection) url.openConnection();

        con.setRequestMethod("GET");

        BufferedReader br = new BufferedReader(
            new InputStreamReader(con.getInputStream()));

        String response = br.readLine();

        System.out.println("Response from Web Service: " + response);

        br.close();
        con.disconnect();
    }
}
