import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) throws Exception {

        HttpServer server = HttpServer.create(
            new InetSocketAddress(8080), 0);

        server.createContext("/add", exchange -> {

            String query = exchange.getRequestURI().getQuery();
            String[] values = query.split("&");

            int a = Integer.parseInt(values[0].split("=")[1]);
            int b = Integer.parseInt(values[1].split("=")[1]);

            int sum = a + b;

            String response = "Sum = " + sum;

            exchange.sendResponseHeaders(200, response.length());

            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        });

        server.start();

        System.out.println("Web Service Started at port 8080");
    }
}
