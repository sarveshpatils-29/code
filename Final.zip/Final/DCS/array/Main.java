import java.util.Scanner;

class SumThread extends Thread {
    int[] a;
    int start, end, sum = 0;
    int id;

    SumThread(int[] a, int start, int end, int id) {
        this.a = a;
        this.start = start;
        this.end = end;
        this.id = id;
    }

    public void run() {
        for (int i = start; i < end; i++) {
            sum += a[i];
        }
    }
}

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements: ");
        int n = sc.nextInt();

        int[] a = new int[n];

        System.out.println("Enter array elements:");
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }

        System.out.print("Enter number of threads: ");
        int p = sc.nextInt();

        if (p < 1 || p > n) {
            System.out.println("Invalid number of threads");
            return;
        }

        SumThread[] t = new SumThread[p];

        for (int i = 0; i < p; i++) {
            int start = i * n / p;
            int end = (i + 1) * n / p;

            t[i] = new SumThread(a, start, end, i);
            t[i].start();
        }

        int total = 0;

        for (int i = 0; i < p; i++) {
            t[i].join();
            System.out.println("Thread " + i + " sum = " + t[i].sum);
            total += t[i].sum;
        }

        System.out.println("Total Sum = " + total);

        sc.close();
    }
}
