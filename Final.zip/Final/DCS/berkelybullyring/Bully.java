
import java.util.Scanner;

public class Bully {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of processes: ");
        int n = sc.nextInt();

        boolean[] active = new boolean[n + 1];

        for (int i = 1; i <= n; i++) {
            active[i] = true;
        }

        System.out.print("Enter failed process ID: ");
        int failed = sc.nextInt();

        if (failed < 1 || failed > n) {
            System.out.println("Invalid process ID");
            return;
        }

        active[failed] = false;

        System.out.print("Enter process ID starting election: ");
        int election = sc.nextInt();

        if (election < 1 || election > n || !active[election]) {
            System.out.println("Invalid election process");
            return;
        }

        System.out.println("\nProcess " + election + " starts election.");

        boolean higherFound = false;

        for (int i = election + 1; i <= n; i++) {
            if (active[i]) {
                System.out.println("Election message sent to P" + i);
                System.out.println("P" + i + " responds OK.");
                higherFound = true;
            }
        }

        int leader = 0;

        for (int i = n; i >= 1; i--) {
            if (active[i]) {
                leader = i;
                break;
            }
        }

        if (!higherFound) {
            System.out.println("No higher process is active.");
        }

        System.out.println("\nP" + leader + " becomes the new coordinator.");

        System.out.println("Coordinator message sent to all active processes.");

        sc.close();
    }
}
