import java.util.Scanner;

public class Berkeley {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of computers: ");
        int n = sc.nextInt();

        int[] clock = new int[n];
        int total = 0;

        System.out.println("Enter clock times in minutes:");

        for (int i = 0; i < n; i++) {
            System.out.print("Computer " + (i + 1) + ": ");
            clock[i] = sc.nextInt();
            total += clock[i];
        }

        int average = total / n;

        System.out.println("\nAverage clock time = " + average);

        System.out.println("\nClock adjustments:");

        for (int i = 0; i < n; i++) {
            int adjustment = average - clock[i];

            System.out.println("Computer " + (i + 1) +
                    " adjustment = " + adjustment + " minutes");

            clock[i] = average;
        }

        System.out.println("\nSynchronized Clock Times:");

        for (int i = 0; i < n; i++) {
            System.out.println("Computer " + (i + 1) +
                    " = " + clock[i]);
        }

        sc.close();
    }
}
