
import java.util.Scanner;

public class Ring {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of processes: ");
        int n = sc.nextInt();

        boolean[] active = new boolean[n + 1];

        for (int i = 1; i <= n; i++) {
            active[i] = true;
        }

        System.out.print("Enter failed process ID: ");
        int failed = sc.nextInt();

        if (failed < 1 || failed > n) {
            System.out.println("Invalid process ID");
            return;
        }

        active[failed] = false;

        System.out.print("Enter process ID starting election: ");
        int start = sc.nextInt();

        if (start < 1 || start > n || !active[start]) {
            System.out.println("Invalid election process");
            return;
        }

        System.out.println("\nElection started by P" + start);

        int leader = start;

        System.out.println("Election message travels around the ring:");

        for (int i = 1; i <= n; i++) {
            int id = (start + i - 1) % n + 1;

            if (active[id]) {
                System.out.println("Process P" + id + " participates.");
                if (id > leader) {
                    leader = id;
                }
            }
        }

        System.out.println("\nP" + leader + " becomes the new coordinator.");

        System.out.println("Coordinator message circulated around the ring.");

        sc.close();
    }
}
