
import nltk
import os
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('wordnet')
nltk.download('stopwords')


folder = r"C:\Users\Shubham\Downloads\Final\ISR\conflationalgorithm\Textdocuments"

documents = {}

for file in os.listdir(folder):
    if file.endswith(".txt"):
        with open(os.path.join(folder, file), "r", encoding="utf-8") as f:
            documents[file] = f.read()

stop_words = set(stopwords.words('english'))
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

processed = []


for name, document in documents.items():

    tokens = word_tokenize(document.lower())

    words = [word for word in tokens
             if word.isalnum() and word not in stop_words]

    print("\nDocument:", name)
    print("Remove stopwords:", words)

    conflated_terms = [stemmer.stem(word) for word in words]
    print("Conflated Terms:", conflated_terms)

    lemmatized_words = [lemmatizer.lemmatize(word) for word in words]
    print("Lemmatized Words:", lemmatized_words)

    document_representation = {}

    for term in conflated_terms:
        document_representation[term] = document_representation.get(term, 0) + 1

    print("Document Representation:", document_representation)

    processed.append(" ".join(conflated_terms))



vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(processed).toarray()

clusters = []
threshold = 0.15

for i, doc in enumerate(X):

    found = False

    for cluster in clusters:

        similarity = cosine_similarity(
            [doc], [cluster["centroid"]]
        )[0][0]

        if similarity >= threshold:
            cluster["docs"].append(i)
            cluster["centroid"] = X[cluster["docs"]].mean(axis=0)
            found = True
            break

    if not found:
        clusters.append({
            "docs": [i],
            "centroid": doc.copy()
        })



print("\n----- SINGLE PASS CLUSTERING -----")

for i, cluster in enumerate(clusters):
    print("\nCluster", i + 1)

    for j in cluster["docs"]:
        print(list(documents.keys())[j])

print("\nTotal Documents:", len(documents))
print("Total Clusters:", len(clusters))
print("Clustering Completed Successfully!")
